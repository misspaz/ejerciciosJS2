let name = 'Abel';
let surname = 'Cabeza Román';
let years = 99;


years = 100;

console.log('Me llamo ' + name + ' ' + surname + ' y tengo ' + years + ' años');