
// alert("Hey, soy muy pesao");
// const isConfirmed = confirm("Confirmame");
// const age = prompt("¿Cuantos años tienes?");

const finalName = "Peter Parker"; // Creamos una variable y la inicializamos
console.log(finalName);
let edad; // Creamos una variable sin inicializarla con un valor
console.log(edad); // Imprime por pantalla: undefined --> Porque la variable existe, pero no tiene valor dentro
edad = 16; // Ahora le damos valor
console.log(edad); // Imprime por pantalla: 16

let a = 5;

// a = "Abel"
// a = true;
// a = {};

const b = 2;

const c = a % b;





a += 1;

a = a + 1;
 
a -= 1;
a = a - 1;

a *= 2;
a = a * 2;

a /= 2;
a = a / 2;


const y = "Soy";
const u = "un gorgonita";

console.log(y + " " + u); // Soy un gorgonita


const user = {
    name: "Abel",
    surname: "Cabeza",
    age: 99,
    isTeacher: true,
};

console.log(user.name);// Abel
console.log(user["name"]); // Abel
console.log(user.age); // 99
console.log(user.isTeacher); // true

user.age = 100;

console.log(user.age) // 100








