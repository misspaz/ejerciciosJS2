console.log("Hola este es mi primer mensaje");

console.log("Hasdasd");

console.log(typeof "pepe");