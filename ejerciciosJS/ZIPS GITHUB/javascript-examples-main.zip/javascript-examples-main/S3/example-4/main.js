const div$$ = document.createElement('div');

document.body.appendChild(div$$);



const p$$ = document.createElement('p');


// const p$$ = document.createElement('span');

// const insertHere$$ = document.querySelector('[data-function="insertHere"]');

// insertHere$$.appendChild(p$$);




