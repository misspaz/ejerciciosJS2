import pepe, {name as juan} from './example-1-export';

console.log(juan);

pepe();