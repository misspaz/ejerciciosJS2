// console.log(prueba);

const prueba = 10;

console.log(prueba);

setTimeout(function () {
    console.log(1)
}, 1000);

console.log(2)
